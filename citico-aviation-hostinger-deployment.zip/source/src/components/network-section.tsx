"use client";

import { Reveal, SectionHead } from "@/components/ui";
import { useDict } from "@/components/locale-provider";

export function NetworkSection() {
  const { network, sections } = useDict();
  return (
    <section className="relative overflow-hidden py-24 sm:py-32">
      <div className="absolute inset-0" style={{ background: "linear-gradient(180deg,#052452 0%,#083672 50%,#0d4a9b 100%)" }} aria-hidden />
      <div className="absolute left-1/2 top-0 h-[420px] w-[720px] -translate-x-1/2 rounded-full opacity-20 blur-3xl" style={{ background: "radial-gradient(closest-side, rgba(45,140,255,0.55), transparent)" }} aria-hidden />
      <div className="section-pad relative mx-auto max-w-[1400px]">
        <SectionHead
          dark
          kicker={sections.networkKicker}
          title={<>{sections.networkTitle.lead} <span className="text-gradient">{sections.networkTitle.accent}</span></>}
          sub={sections.networkSub}
        />

        <Reveal className="relative mt-14">
          <div className="relative overflow-hidden rounded-3xl border border-white/10 bg-white/[0.03] p-8 sm:p-12">
            {/* Network visualization */}
            <div className="relative flex flex-col items-center gap-8 lg:flex-row lg:justify-center lg:gap-16">
              {/* Hub */}
              <div className="relative flex flex-col items-center">
                <div className="flex h-20 w-20 items-center justify-center rounded-full border-2 border-citico-500 bg-citico-600/20 shadow-[0_0_40px_-8px_rgba(45,140,255,0.6)]">
                  <span className="font-display text-lg font-bold text-white">{network.hub}</span>
                </div>
                <div className="mt-2 text-center">
                  <p className="text-[12px] font-bold uppercase tracking-[0.2em] text-citico-400">{sections.networkHubLabel}</p>
                  <p className="text-[12px] text-slate-500">{sections.networkHubCountry}</p>
                </div>
                {/* Radiating lines (desktop) */}
                <div className="absolute left-1/2 top-1/2 hidden -translate-x-1/2 -translate-y-1/2 lg:block" aria-hidden>
                  <svg width="600" height="300" viewBox="0 0 600 300" fill="none" className="opacity-30">
                    {/* Lines from center to each destination */}
                    {network.connections.map((_, i) => {
                      const angle = (i / network.connections.length) * Math.PI - Math.PI / 2;
                      const x2 = 300 + Math.cos(angle) * 260;
                      const y2 = 150 + Math.sin(angle) * 130;
                      return (
                        <line key={i} x1="300" y1="150" x2={x2} y2={y2} stroke="#7CC4FF" strokeWidth="1" strokeDasharray="4 4" />
                      );
                    })}
                  </svg>
                </div>
              </div>

              {/* Destinations grid */}
              <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-2 xl:grid-cols-3">
                {network.connections.map((dest, i) => (
                  <Reveal key={dest.code} delay={i * 0.06}>
                    <div className="group flex items-center gap-3 rounded-xl border border-white/10 bg-white/[0.04] px-5 py-4 transition-all duration-300 hover:border-citico-400/40 hover:bg-white/[0.07]">
                      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-[#0078FF]/25 text-[12px] font-bold text-[#7CC4FF]">
                        {dest.code}
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-white">{dest.city}</p>
                        <p className="text-[12px] text-slate-500">{dest.country}</p>
                      </div>
                    </div>
                  </Reveal>
                ))}
              </div>
            </div>

            {/* Domestic destinations */}
            <Reveal delay={0.3}>
              <div className="mt-10 border-t border-white/10 pt-8">
                <p className="mb-4 text-[12px] font-bold uppercase tracking-[0.2em] text-slate-500">{sections.networkDomestic}</p>
                <div className="flex flex-wrap gap-2">
                  {network.domestic.map((city) => (
                    <span key={city} className="rounded-full border border-white/10 bg-white/[0.04] px-4 py-2 text-[13px] font-medium text-slate-300">
                      {city}
                    </span>
                  ))}
                </div>
              </div>
            </Reveal>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
