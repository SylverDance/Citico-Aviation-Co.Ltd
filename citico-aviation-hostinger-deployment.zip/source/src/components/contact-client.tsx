"use client";

import { useState } from "react";
import { Reveal } from "@/components/ui";
import { IconClock, IconMail, IconMapPin, IconPhone } from "@/components/icons";
import { useDict } from "@/components/locale-provider";
import { fmt } from "@/lib/i18n";

type FormState = { name: string; org: string; email: string; service: string; message: string };
type Status = "idle" | "submitting" | "success" | "error";

/*
 * ─── FORMSPREE SETUP ───────────────────────────────────────────────────────
 *  1. Go to https://formspree.io and sign up for a free account.
 *  2. Create a new form and point it to citicoaviation@gmail.com
 *     (or your domain email once that's set up).
 *  3. Copy the Form ID (e.g. xrgvkwpb) from the Formspree dashboard.
 *  4. Replace "YOUR_FORM_ID" below with that ID.
 *  5. Run `npm run build` and redeploy to Hostinger.
 * ──────────────────────────────────────────────────────────────────────────
 */
const FORMSPREE_ENDPOINT = "https://formspree.io/f/YOUR_FORM_ID";

const inputCls =
  "w-full rounded-xl border border-navy-900/12 bg-white px-4 py-3 text-sm text-navy-900 placeholder:text-navy-700/40 outline-none transition-colors focus:border-citico-500 dark:border-white/15 dark:bg-white/5 dark:text-white dark:placeholder:text-slate-500";

export function ContactClient() {
  const { company, services, pages } = useDict();
  const [form, setForm] = useState<FormState>({
    name: "",
    org: "",
    email: "",
    service: services[0].title,
    message: "",
  });
  const [status, setStatus] = useState<Status>("idle");
  const [errorMsg, setErrorMsg] = useState("");

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus("submitting");
    setErrorMsg("");

    try {
      const res = await fetch(FORMSPREE_ENDPOINT, {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify({
          name: form.name,
          organization: form.org,
          email: form.email,
          service: form.service,
          mission_details: form.message,
          _subject: `Charter / Mission Request — ${form.service} — ${form.name}`,
        }),
      });

      if (res.ok) {
        setStatus("success");
        setForm({ name: "", org: "", email: "", service: services[0].title, message: "" });
      } else {
        const data = await res.json().catch(() => ({}));
        setErrorMsg(
          (data as { error?: string }).error ||
            "Something went wrong. Please call us directly or email citicoaviation@gmail.com."
        );
        setStatus("error");
      }
    } catch {
      setErrorMsg(
        "Network error — please check your connection and try again, or call our operations desk directly."
      );
      setStatus("error");
    }
  };

  const set =
    (k: keyof FormState) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) =>
      setForm((f) => ({ ...f, [k]: e.target.value }));

  return (
    <section className="section-pad mx-auto max-w-[1400px] py-20 sm:py-24">
      <div className="grid gap-10 lg:grid-cols-[1fr_1.1fr]">
        {/* ── Contact details ── */}
        <div className="space-y-6">
          <Reveal>
            <div className="rounded-3xl border border-navy-900/8 bg-white/70 p-7 dark:border-white/10 dark:bg-white/5">
              <h2 className="font-display text-lg font-bold text-navy-900 dark:text-white">
                {pages.contact.headOfficeTitle}
              </h2>
              <ul className="mt-5 space-y-5 text-sm">
                <li className="flex gap-3.5">
                  <IconMapPin className="mt-0.5 h-5 w-5 shrink-0 text-citico-600 dark:text-citico-300" />
                  <span className="text-navy-700/85 dark:text-slate-300/90">{company.hq}</span>
                </li>
                <li className="flex gap-3.5">
                  <IconPhone className="mt-0.5 h-5 w-5 shrink-0 text-citico-600 dark:text-citico-300" />
                  <span className="text-navy-700/85 dark:text-slate-300/90">
                    {company.phones.map((p) => (
                      <a
                        key={p}
                        href={`tel:${p.replace(/\s/g, "")}`}
                        className="block transition-colors hover:text-citico-700 dark:hover:text-citico-300"
                      >
                        {p}
                      </a>
                    ))}
                  </span>
                </li>
                <li className="flex gap-3.5">
                  <IconMail className="mt-0.5 h-5 w-5 shrink-0 text-citico-600 dark:text-citico-300" />
                  <span className="text-navy-700/85 dark:text-slate-300/90">
                    <a
                      href={`mailto:${company.email}`}
                      className="block transition-colors hover:text-citico-700 dark:hover:text-citico-300"
                    >
                      {company.email}
                    </a>
                    <a
                      href={`mailto:${company.businessEmail}`}
                      className="block transition-colors hover:text-citico-700 dark:hover:text-citico-300"
                    >
                      {company.businessEmail}
                    </a>
                  </span>
                </li>
                <li className="flex gap-3.5">
                  <IconClock className="mt-0.5 h-5 w-5 shrink-0 text-citico-600 dark:text-citico-300" />
                  <span className="text-navy-700/85 dark:text-slate-300/90">
                    {fmt(pages.contact.deskLineTemplate, { website: company.website })}
                  </span>
                </li>
              </ul>
            </div>
          </Reveal>

          {/* ── 24/7 Quick-dial panel ── */}
          <Reveal delay={0.06}>
            <div className="rounded-3xl bg-gradient-to-br from-citico-700 to-citico-900 p-7 text-white">
              <p className="text-[11.5px] font-bold uppercase tracking-[0.28em] text-citico-200">
                Urgent mission?
              </p>
              <p className="mt-2 text-[17px] font-bold leading-tight">
                Call our 24/7 operations desk
              </p>
              <p className="mt-1.5 text-[13.5px] text-citico-100/75">
                For time-critical charters, medevac and emergency cargo.
              </p>
              <div className="mt-5 flex flex-col gap-2">
                {company.phones.map((p) => (
                  <a
                    key={p}
                    href={`tel:${p.replace(/\s/g, "")}`}
                    className="inline-flex items-center gap-2.5 rounded-xl bg-white/10 px-4 py-3 text-[14.5px] font-bold transition-colors hover:bg-white/20"
                  >
                    <IconPhone className="h-4 w-4 shrink-0 text-citico-300" />
                    {p}
                  </a>
                ))}
              </div>
            </div>
          </Reveal>

          {/* ── Map ── */}
          <Reveal delay={0.1}>
            <div className="relative min-h-[300px] overflow-hidden rounded-3xl border border-navy-900/8 dark:border-white/10">
              <iframe
                title={pages.contact.mapTitle}
                src="https://www.openstreetmap.org/export/embed.html?bbox=31.565%2C4.845%2C31.605%2C4.885&layer=mapnik&marker=4.865%2C31.585"
                className="absolute inset-0 h-full w-full border-0"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </Reveal>
        </div>

        {/* ── Charter request form ── */}
        <Reveal delay={0.1}>
          <div
            id="charter"
            className="scroll-mt-28 rounded-3xl border border-navy-900/8 bg-white/70 p-7 dark:border-white/10 dark:bg-white/5 sm:p-9"
          >
            <h2 className="font-display text-2xl font-bold text-navy-900 dark:text-white">
              {pages.contact.formTitle}
            </h2>
            <p className="mt-2 text-sm text-navy-700/70 dark:text-slate-400">
              {pages.contact.formSub}
            </p>

            {/* ── Success state ── */}
            {status === "success" ? (
              <div
                role="alert"
                className="mt-8 rounded-2xl border border-green-400/40 bg-green-50 p-6 dark:border-green-500/30 dark:bg-green-900/20"
              >
                <div className="flex items-start gap-3">
                  <svg
                    className="mt-0.5 h-5 w-5 shrink-0 text-green-600 dark:text-green-400"
                    viewBox="0 0 20 20"
                    fill="currentColor"
                    aria-hidden
                  >
                    <path
                      fillRule="evenodd"
                      d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.857-9.809a.75.75 0 00-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 10-1.06 1.061l2.5 2.5a.75.75 0 001.137-.089l4-5.5z"
                      clipRule="evenodd"
                    />
                  </svg>
                  <div>
                    <p className="font-semibold text-green-800 dark:text-green-200">
                      {pages.contact.sentTitle}
                    </p>
                    <p className="mt-1.5 text-sm text-green-700/85 dark:text-green-300/80">
                      {pages.contact.sentBody}
                    </p>
                    <p className="mt-3 text-sm font-medium text-green-800 dark:text-green-200">
                      Need a faster response?{" "}
                      <a
                        href={`tel:${company.phones[0].replace(/\s/g, "")}`}
                        className="underline hover:no-underline"
                      >
                        Call {company.phones[0]}
                      </a>
                    </p>
                  </div>
                </div>
              </div>
            ) : (
              <form onSubmit={submit} className="mt-7 space-y-4" noValidate>
                <div className="grid gap-4 sm:grid-cols-2">
                  <label className="block">
                    <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-navy-700/70 dark:text-slate-400">
                      {pages.contact.fieldName}
                    </span>
                    <input
                      required
                      value={form.name}
                      onChange={set("name")}
                      className={inputCls}
                      placeholder={pages.contact.fieldNamePlaceholder}
                      autoComplete="name"
                    />
                  </label>
                  <label className="block">
                    <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-navy-700/70 dark:text-slate-400">
                      {pages.contact.fieldOrg}
                    </span>
                    <input
                      value={form.org}
                      onChange={set("org")}
                      className={inputCls}
                      placeholder={pages.contact.fieldOrgPlaceholder}
                      autoComplete="organization"
                    />
                  </label>
                </div>
                <label className="block">
                  <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-navy-700/70 dark:text-slate-400">
                    {pages.contact.fieldEmail}
                  </span>
                  <input
                    required
                    type="email"
                    value={form.email}
                    onChange={set("email")}
                    className={inputCls}
                    placeholder={pages.contact.fieldEmailPlaceholder}
                    autoComplete="email"
                  />
                </label>
                <label className="block">
                  <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-navy-700/70 dark:text-slate-400">
                    {pages.contact.fieldService}
                  </span>
                  <select value={form.service} onChange={set("service")} className={inputCls}>
                    {services.map((s) => (
                      <option key={s.slug} value={s.title}>
                        {s.title}
                      </option>
                    ))}
                    <option value={pages.contact.fieldOther}>{pages.contact.fieldOther}</option>
                  </select>
                </label>
                <label className="block">
                  <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-navy-700/70 dark:text-slate-400">
                    {pages.contact.fieldMessage}
                  </span>
                  <textarea
                    required
                    rows={5}
                    value={form.message}
                    onChange={set("message")}
                    className={inputCls}
                    placeholder={pages.contact.fieldMessagePlaceholder}
                  />
                </label>

                {/* ── Error message ── */}
                {status === "error" && (
                  <div
                    role="alert"
                    className="rounded-xl border border-red-300/50 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-500/30 dark:bg-red-900/20 dark:text-red-300"
                  >
                    {errorMsg}
                  </div>
                )}

                <button
                  type="submit"
                  disabled={status === "submitting"}
                  className="flex w-full items-center justify-center gap-2.5 rounded-full bg-citico-700 px-6 py-3.5 text-sm font-semibold text-white shadow-[0_12px_32px_-12px_rgba(12,12,120,0.6)] transition-all hover:-translate-y-0.5 hover:bg-citico-600 disabled:cursor-not-allowed disabled:opacity-60 dark:bg-citico-500 dark:hover:bg-citico-400"
                >
                  {status === "submitting" ? (
                    <>
                      <svg className="h-4 w-4 animate-spin" viewBox="0 0 24 24" fill="none" aria-hidden>
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                      </svg>
                      Sending…
                    </>
                  ) : (
                    pages.contact.submit
                  )}
                </button>

                <p className="text-center text-[11.5px] text-navy-700/45 dark:text-slate-500">
                  Your mission details are handled with strict confidentiality.
                </p>
              </form>
            )}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
