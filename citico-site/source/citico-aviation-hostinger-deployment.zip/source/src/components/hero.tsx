"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { AnimatePresence, motion, useInView } from "framer-motion";
import { useDict, useLocalizedHref } from "@/components/locale-provider";
import { fmt } from "@/lib/i18n";
import { IconArrow, IconJet, IconBox, IconClock, IconMail } from "@/components/icons";

gsap.registerPlugin(ScrollTrigger);

const widgetIcons: Record<string, React.ReactNode> = {
  charter: <IconJet className="h-4 w-4" />,
  track: <IconBox className="h-4 w-4" />,
  status: <IconClock className="h-4 w-4" />,
  quote: <IconMail className="h-4 w-4" />,
};

/* ─── rAF detection: if dead, skip entrance animations so nothing is stuck invisible ─── */
function useRafWorking() {
  const [ok, setOk] = useState(true);
  useEffect(() => {
    let fired = false;
    const id = requestAnimationFrame(() => { fired = true; });
    const t = setTimeout(() => { if (!fired) setOk(false); cancelAnimationFrame(id); }, 800);
    return () => { cancelAnimationFrame(id); clearTimeout(t); };
  }, []);
  return ok;
}

/* Animated counter — renders the real final value as the SSR/initial default.
   This means even on slow connections or with JS blocked, users see "13+" not "0".
   When JS runs and the element enters the viewport, the counter animates from 0
   up to the target value as before. */
function CountUp({ value, suffix = "", display: displayLabel }: { value: number; suffix?: string; display?: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-40px" });
  // Default to the real final value — SSR-safe, no flash of "0" on load
  const [display, setDisplay] = useState(value);
  useEffect(() => {
    if (!inView) return;
    const dur = 1400;
    const start = performance.now();
    let raf = 0;
    const tick = (now: number) => {
      const p = Math.min((now - start) / dur, 1);
      setDisplay(Math.round((1 - Math.pow(1 - p, 3)) * value));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    // Brief delay to allow entrance animation to complete before counter starts
    const timeout = setTimeout(() => { raf = requestAnimationFrame(tick); }, 200);
    return () => { cancelAnimationFrame(raf); clearTimeout(timeout); };
  }, [inView, value]);
  // Use displayLabel override if provided (e.g. "24/7" instead of computed "24")
  return <span ref={ref}>{displayLabel ?? display}{suffix}</span>;
}

export function Hero() {
  const { heroSlides, heroTrust, heroWidgetTabs, hero } = useDict();
  const lhref = useLocalizedHref();
  const root = useRef<HTMLElement>(null);
  const imgWrap = useRef<HTMLDivElement>(null);
  const [slide, setSlide] = useState(0);
  const [widgetTab, setWidgetTab] = useState("charter");
  const [destinationInput, setDestinationInput] = useState("");
  const [quoteNameInput, setQuoteNameInput] = useState("");
  const [quoteEmailInput, setQuoteEmailInput] = useState("");
  const [trackInput, setTrackInput] = useState("");
  const [scrolledPast, setScrolledPast] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);
  const rafWorking = useRafWorking();
  const [mouse, setMouse] = useState({ x: 0, y: 0 });
  const rafMouse = useRef(0);
  const mouseTarget = useRef({ x: 0, y: 0 });

  /* Respect prefers-reduced-motion */
  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const sync = () => setReducedMotion(mq.matches);
    sync();
    mq.addEventListener("change", sync);
    return () => mq.removeEventListener("change", sync);
  }, []);

  /* Mouse parallax — smoothed lerp, max ±12px x / ±8px y */
  useEffect(() => {
    if (reducedMotion || !rafWorking) return;
    const onMove = (e: MouseEvent) => {
      const nx = (e.clientX / window.innerWidth - 0.5) * 2;
      const ny = (e.clientY / window.innerHeight - 0.5) * 2;
      mouseTarget.current = { x: nx * -12, y: ny * -8 };
    };
    const tick = () => {
      setMouse((m) => ({
        x: m.x + (mouseTarget.current.x - m.x) * 0.06,
        y: m.y + (mouseTarget.current.y - m.y) * 0.06,
      }));
      rafMouse.current = requestAnimationFrame(tick);
    };
    window.addEventListener("mousemove", onMove, { passive: true });
    rafMouse.current = requestAnimationFrame(tick);
    return () => { window.removeEventListener("mousemove", onMove); cancelAnimationFrame(rafMouse.current); };
  }, [reducedMotion]);

  /* Carousel auto-advance */
  useEffect(() => {
    const iv = setInterval(() => setSlide((s) => (s + 1) % heroSlides.length), 7000);
    return () => clearInterval(iv);
  }, []);

  /* GSAP parallax + aircraft float */
  useEffect(() => {
    if (reducedMotion || !rafWorking) return;
    const ctx = gsap.context(() => {
      /* Never scale below 1 — a <1 scale shrinks the photo inside the fixed hero
         box and exposes the background as empty bands on the left/right edges. */
      gsap.fromTo(".hero-zoom", { scale: 1.12 }, { scale: 1.06, duration: 3, ease: "power2.out" });
      gsap.to(".hero-float", {
        y: -8, rotate: -0.3, duration: 10, ease: "sine.inOut", repeat: -1, yoyo: true,
      });
      if (imgWrap.current) {
        gsap.to(imgWrap.current, {
          y: -40, ease: "none",
          scrollTrigger: { trigger: root.current, start: "top top", end: "bottom top", scrub: 0.6 },
        });
      }
    }, root);
    return () => ctx.revert();
  }, [reducedMotion, rafWorking]);

  /* Floating mobile CTA */
  useEffect(() => {
    const check = () => setScrolledPast(window.scrollY > window.innerHeight * 0.85);
    check();
    window.addEventListener("scroll", check, { passive: true });
    const iv = setInterval(check, 300);
    return () => { window.removeEventListener("scroll", check); clearInterval(iv); };
  }, []);

  /* Pre-cropped masters so the frame is filled edge-to-edge at every aspect ratio:
     desktop = 2:1 panorama (tail → nose → boarding stairs), tablet = portrait,
     mobile = portrait crop. These are written as an explicit <picture> rather than
     getImageProps because production ships as a static export with no Next.js image
     optimizer — and the three files are already the exact crops the layout wants. */
  const heroAlt =
    "CITICO Aviation cargo aircraft being loaded on the tarmac at sunrise";
  const heroDeskSrc = "/img/hero-tarmac.webp";
  const heroTabSrc = "/img/hero-tarmac-tablet.webp";
  const heroMobSrc = "/img/hero-tarmac-mobile.webp";

  const currentSlide = heroSlides[slide];
  const countStats = hero.countStats;

  return (
    <>
      <section
        ref={root}
        className={`relative flex min-h-[calc(100svh-71px)] max-h-[880px] flex-col justify-center overflow-hidden bg-[#0a1628] pt-[71px] sm:pt-[79px] ${
          rafWorking ? "" : "no-raf-fallback"
        }`}
      >
        {/* ─── Aircraft image — right focal point, mouse parallax ─── */}
        {/* The image fills the whole frame edge-to-edge and is held above scale 1, so
            the parallax, tilt and scroll drift never expose the background as
            empty bands on the left/right of the hero. */}
        <div
          ref={imgWrap}
          className="hero-float absolute inset-0 will-change-transform"
          style={{ transform: `translate3d(${mouse.x}px, ${mouse.y}px, 0)`, transition: "transform 0.1s linear" }}
        >
          <div className="hero-zoom absolute inset-0">
            <picture>
              <source media="(max-width: 639px)" srcSet={heroMobSrc} />
              <source media="(min-width: 640px) and (max-width: 1100px)" srcSet={heroTabSrc} />
              <img
                src={heroDeskSrc}
                alt={heroAlt}
                width={1920}
                height={960}
                fetchPriority="high"
                decoding="async"
                className="h-full w-full scale-[1.06] object-cover object-[56%_45%]"
              />
            </picture>
          </div>
        </div>

        {/* ─── Layered modern gradient background (brand blues, royal blue, sky highlights) ─── */}
        <div
          className="absolute inset-0"
          style={{
            background:
              "linear-gradient(180deg, rgba(7,28,59,0.10) 0%, rgba(7,28,59,0.05) 30%, rgba(8,60,130,0.12) 68%, rgba(7,45,95,0.38) 84%, rgba(5,22,48,0.62) 100%)",
          }}
        />
        {/* Top-to-bottom deep navy to transparent — softens the sky behind the nav */}
        <div
          className="absolute inset-0"
          style={{
            background:
              "linear-gradient(180deg, rgba(7,28,59,0.48) 0%, rgba(7,28,59,0.20) 22%, rgba(8,45,95,0.05) 45%, rgba(8,60,130,0.00) 70%)",
          }}
        />
        {/* Sky-blue glow from far right (behind aircraft) */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse 60%_45% at 85%_40%,rgba(45,140,255,0.08),transparent_65%)]" />
        {/* Under-text scrim — text side only (mirrored automatically in RTL via CSS) */}
        <div className="hero-text-scrim absolute inset-0" />
        {/* Bottom vignette for widget readability */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a1628]/55 via-transparent to-transparent" />

        {/* ─── Cinematic atmosphere layers ─── */}
        {!reducedMotion && (
          <>
            <motion.div
              aria-hidden
              className="pointer-events-none absolute inset-0 will-change-transform"
              animate={{ x: ["0%", "-3%"] }}
              transition={{ duration: 45, repeat: Infinity, ease: "linear" }}
              style={{
                background:
                  "radial-gradient(ellipse 55% 28% at 75% 65%, rgba(255,255,255,0.04), transparent 70%), radial-gradient(ellipse 40% 20% at 58% 78%, rgba(255,220,170,0.035), transparent 70%)",
                backgroundSize: "160% 160%",
              }}
            />
            <motion.div
              aria-hidden
              className="pointer-events-none absolute inset-0 will-change-transform"
              animate={{ x: ["-40%", "40%"], opacity: [0, 0.4, 0] }}
              transition={{ duration: 14, repeat: Infinity, ease: "easeInOut", times: [0, 0.5, 1] }}
              style={{
                background:
                  "linear-gradient(105deg, transparent 40%, rgba(255,214,150,0.08) 48%, rgba(255,235,200,0.12) 52%, rgba(255,214,150,0.08) 56%, transparent 64%)",
                mixBlendMode: "soft-light",
              }}
            />
          </>
        )}

        {/* ─── Hero Content — premium spacing ─── */}
        <div className="section-pad relative z-10 mx-auto w-full max-w-[1400px] py-10 sm:py-14 lg:py-16">
          <div className="max-w-full sm:max-w-[min(700px,62vw)] lg:max-w-[min(780px,58vw)]">

            {/* Eyebrow — small aviation label */}
            <motion.p
              initial={rafWorking ? { opacity: 0, y: 12 } : false}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.15 }}
              className="mb-4 inline-flex items-center gap-3 text-[12px] font-bold uppercase tracking-[0.32em] text-[#7CC4FF] sm:text-[12.5px]"
            >
              <span className="inline-block h-[2px] w-9 bg-gradient-to-r from-[#7CC4FF] to-[#5aabff] opacity-70" aria-hidden />
              {hero.eyebrow}
            </motion.p>

            {/* ─── Headline — massive 2-line with accent ─── */}
            <div className="relative min-h-[clamp(4.4rem,9vw,8rem)]">
              <AnimatePresence mode="wait">
                <motion.h1
                  key={slide}
                  initial={rafWorking ? { opacity: 0, y: 20 } : false}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -12 }}
                  transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
                  className="font-display leading-[1.02] tracking-[-0.02em] text-white"
                >
                  <span className="block text-[clamp(2rem,4vw,3.5rem)] font-bold leading-[1.08]">
                    {currentSlide.headline[0]}
                  </span>
                  <span className="block text-[clamp(2rem,4vw,3.5rem)] font-extrabold leading-[1.08] bg-gradient-to-r from-[#7CC4FF] via-[#5aabff] to-[#3D9BFF] bg-clip-text text-transparent">
                    {currentSlide.headline[1]}
                  </span>
                </motion.h1>
              </AnimatePresence>
            </div>

            {/* ─── Supporting description ─── */}
            <AnimatePresence mode="wait">
              <motion.p
                key={slide}
                initial={rafWorking ? { opacity: 0, y: 8 } : false}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                transition={{ duration: 0.45, delay: 0.08 }}
                className="hero-subtext mt-4 max-w-[500px] text-[13px] leading-[1.65] text-white/85 sm:text-[14.5px]"
              >
                {currentSlide.subtext}
              </motion.p>
            </AnimatePresence>

            {/* ─── Trust indicators — clean horizontal row ─── */}
            <motion.div
              initial={rafWorking ? { opacity: 0, y: 10 } : false}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.35 }}
              className="hero-trust mt-6 flex flex-wrap items-center gap-x-6 gap-y-2"
            >
              {heroTrust.map((t, i) => (
                <span key={t} className="inline-flex items-center gap-1.5 text-[12px] font-medium text-white/90 sm:text-[12.5px]">
                  <svg viewBox="0 0 16 16" className="h-3.5 w-3.5 shrink-0 text-[#7CC4FF]" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                    <path d="M3 8.5l3.5 3.5L13 4.5" />
                  </svg>
                  {t}
                  {i < heroTrust.length - 1 && <span className="ml-4 hidden h-3 w-px bg-white/20 sm:block" aria-hidden />}
                </span>
              ))}
            </motion.div>

            {/* ─── CTA buttons ─── */}
            {/* ─── Real Conversion CTAs (P0 Revenue Protection) ─── */}
            <motion.div
              initial={rafWorking ? { opacity: 0, y: 14 } : false}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.5 }}
              className="mt-7 flex flex-wrap items-center gap-3"
            >
              <motion.div whileHover={{ y: -2 }} whileTap={{ scale: 0.97 }} transition={{ type: "spring", stiffness: 400, damping: 22 }}>
                <Link
                  href={lhref("/rfq")}
                  className="group inline-flex items-center gap-2.5 rounded-full bg-[#0078FF] px-7 py-3.5 text-[13.5px] font-bold tracking-wide text-white shadow-[0_10px_36px_-8px_rgba(0,120,255,0.60)] transition-all duration-300 hover:bg-[#3D9BFF] hover:shadow-[0_14px_44px_-8px_rgba(0,120,255,0.75)]"
                >
                  <IconJet className="h-4 w-4" />
                  <span>Request Immediate Flight Quote</span>
                  <IconArrow className="h-3.5 w-3.5 transition-transform duration-300 group-hover:translate-x-1" />
                </Link>
              </motion.div>

              <motion.div whileHover={{ y: -2 }} whileTap={{ scale: 0.97 }} transition={{ type: "spring", stiffness: 400, damping: 22 }}>
                <a
                  href="tel:+211924016167"
                  className="inline-flex items-center gap-2 rounded-full border border-white/40 bg-white/10 px-5 py-3.5 text-[13px] font-semibold text-white backdrop-blur-sm transition-all duration-300 hover:border-[#0078FF]/60 hover:bg-[#0078FF]/20"
                >
                  <IconClock className="h-4 w-4 text-[#7CC4FF]" />
                  <span>24/7 Operations Desk</span>
                </a>
              </motion.div>

              <motion.div whileHover={{ y: -2 }} whileTap={{ scale: 0.97 }} transition={{ type: "spring", stiffness: 400, damping: 22 }}>
                <a
                  href="https://wa.me/211924016167?text=Immediate%20Flight%20Charter%20Inquiry%20-%20CITICO%20Aviation"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 rounded-full border border-emerald-400/40 bg-emerald-600/30 px-5 py-3.5 text-[13px] font-semibold text-emerald-300 backdrop-blur-sm transition-all duration-300 hover:bg-emerald-600/50 hover:text-white"
                >
                  <span>💬</span>
                  <span>Chat Operations Team</span>
                </a>
              </motion.div>
            </motion.div>
          </div>

          {/* ─── Widget (Step 1 of RFQ Workflow) ─── */}
          <motion.div
            initial={rafWorking ? { y: 20, opacity: 0 } : false}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.7 }}
            className="hero-widget mt-7 max-w-full sm:max-w-[min(560px,60vw)]"
          >
            <div className="overflow-hidden rounded-2xl bg-white shadow-[0_28px_80px_-24px_rgba(0,15,40,0.65)] ring-1 ring-black/5">
              <div className="grid grid-cols-2 gap-px bg-slate-200">
                {heroWidgetTabs
                  .filter((tab) => tab.key === "charter" || tab.key === "quote")
                  .map((tab) => (
                    <button
                      key={tab.key}
                      onClick={() => setWidgetTab(tab.key)}
                      className={`relative flex items-center justify-center gap-1.5 px-3 py-3.5 text-[12px] font-semibold transition-colors sm:px-6 sm:text-[13px] ${
                        widgetTab === tab.key ? "bg-white text-[#0078FF]" : "bg-slate-50 text-slate-500 hover:bg-white hover:text-navy-800"
                      }`}
                    >
                      <span className="hidden sm:inline">{widgetIcons[tab.key]}</span>
                      {tab.label}
                      {widgetTab === tab.key && (
                        <motion.div
                          layoutId="widget-tab"
                          className="absolute bottom-0 left-0 right-0 h-[2.5px] bg-[#0078FF]"
                          transition={{ type: "spring", stiffness: 400, damping: 30 }}
                        />
                      )}
                    </button>
                  ))}
              </div>
              <div className="bg-[#004ea8] p-4 sm:p-5">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={widgetTab}
                    initial={rafWorking ? { opacity: 0, y: 4 } : false}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -4 }}
                    transition={{ duration: 0.2 }}
                  >
                    {widgetTab === "charter" && (
                      <div className="grid gap-2.5 sm:grid-cols-[1fr_1fr_auto] sm:items-end">
                        <div>
                          <label className="mb-1 block text-[12px] font-bold uppercase tracking-[0.14em] text-white/75">{hero.widget.from}</label>
                          <div className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-[13px] font-bold text-navy-900 shadow-sm">{hero.widget.originValue}</div>
                        </div>
                        <div>
                          <label className="mb-1 block text-[12px] font-bold uppercase tracking-[0.14em] text-white/75">{hero.widget.to}</label>
                          <input
                            type="text"
                            value={destinationInput}
                            onChange={(e) => setDestinationInput(e.target.value)}
                            placeholder={hero.widget.destinationPlaceholder}
                            className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-[13px] font-semibold text-navy-900 placeholder:font-normal placeholder:text-slate-400 focus:border-[#7CC4FF] focus:outline-none"
                          />
                        </div>
                        <Link
                          href={`${lhref("/rfq")}?mission=cargo&from=Juba&to=${encodeURIComponent(destinationInput || "Malakal")}`}
                          className="inline-flex items-center justify-center rounded-lg bg-[#7CC4FF] px-6 py-2.5 text-[13px] font-bold text-navy-950 shadow-sm transition-all hover:bg-white hover:shadow-md"
                        >
                          {hero.widget.search}
                        </Link>
                      </div>
                    )}
                    {widgetTab === "track" && (
                      <div className="grid gap-2.5 sm:grid-cols-[1fr_auto] sm:items-end">
                        <div>
                          <label className="mb-1 block text-[12px] font-bold uppercase tracking-[0.14em] text-white/75">{hero.widget.shipmentLabel}</label>
                          <input
                            type="text"
                            value={trackInput}
                            onChange={(e) => setTrackInput(e.target.value)}
                            placeholder={hero.widget.shipmentPlaceholder}
                            className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-[13px] font-semibold text-navy-900 placeholder:font-normal placeholder:text-slate-400 focus:border-[#7CC4FF] focus:outline-none"
                          />
                        </div>
                        <a
                          href={`https://wa.me/211924016167?text=${encodeURIComponent("Tracking Inquiry for AWB / Shipment #: " + (trackInput || "Pending"))}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center justify-center rounded-lg bg-[#7CC4FF] px-6 py-2.5 text-[13px] font-bold text-navy-950 shadow-sm transition-all hover:bg-white hover:shadow-md"
                        >
                          {hero.widget.track}
                        </a>
                      </div>
                    )}
                    {widgetTab === "status" && (
                      <div className="grid gap-2.5 sm:grid-cols-[1fr_auto] sm:items-end">
                        <div>
                          <label className="mb-1 block text-[12px] font-bold uppercase tracking-[0.14em] text-white/75">{hero.widget.flightLabel}</label>
                          <input
                            type="text"
                            value={trackInput}
                            onChange={(e) => setTrackInput(e.target.value)}
                            placeholder={hero.widget.flightPlaceholder}
                            className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-[13px] font-semibold text-navy-900 placeholder:font-normal placeholder:text-slate-400 focus:border-[#7CC4FF] focus:outline-none"
                          />
                        </div>
                        <a
                          href={`https://wa.me/211924016167?text=${encodeURIComponent("Flight Status Inquiry for Flight #: " + (trackInput || "Current Missions"))}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center justify-center rounded-lg bg-[#7CC4FF] px-6 py-2.5 text-[13px] font-bold text-navy-950 shadow-sm transition-all hover:bg-white hover:shadow-md"
                        >
                          {hero.widget.check}
                        </a>
                      </div>
                    )}
                    {widgetTab === "quote" && (
                      <div className="grid gap-2.5 sm:grid-cols-[1fr_1fr_auto] sm:items-end">
                        <div>
                          <label className="mb-1 block text-[12px] font-bold uppercase tracking-[0.14em] text-white/75">{hero.widget.nameLabel}</label>
                          <input
                            type="text"
                            value={quoteNameInput}
                            onChange={(e) => setQuoteNameInput(e.target.value)}
                            placeholder={hero.widget.namePlaceholder}
                            className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-[13px] font-semibold text-navy-900 placeholder:font-normal placeholder:text-slate-400 focus:border-[#7CC4FF] focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="mb-1 block text-[12px] font-bold uppercase tracking-[0.14em] text-white/75">{hero.widget.emailLabel}</label>
                          <input
                            type="email"
                            value={quoteEmailInput}
                            onChange={(e) => setQuoteEmailInput(e.target.value)}
                            placeholder={hero.widget.emailPlaceholder}
                            className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-[13px] font-semibold text-navy-900 placeholder:font-normal placeholder:text-slate-400 focus:border-[#7CC4FF] focus:outline-none"
                          />
                        </div>
                        <Link
                          href={`${lhref("/rfq")}?name=${encodeURIComponent(quoteNameInput)}&email=${encodeURIComponent(quoteEmailInput)}`}
                          className="inline-flex items-center justify-center rounded-lg bg-[#7CC4FF] px-6 py-2.5 text-[13px] font-bold text-navy-950 shadow-sm transition-all hover:bg-white hover:shadow-md"
                        >
                          {hero.widget.send}
                        </Link>
                      </div>
                    )}
                  </motion.div>
                </AnimatePresence>
              </div>
            </div>
          </motion.div>

          {/* ─── Stats row ─── */}
          <motion.div
            initial={rafWorking ? { y: 14, opacity: 0 } : false}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.5, delay: 1.0 }}
            className="hero-stats mt-7 flex flex-wrap items-baseline gap-x-8 gap-y-2"
          >
            {countStats.map((s) => (
              <div key={s.label} className="flex items-baseline gap-2">
                <span className="font-display text-[18px] font-extrabold text-white sm:text-[22px]">
                  <CountUp
                    value={s.value}
                    suffix={s.suffix}
                  />
                </span>
                <span className="text-[12px] font-semibold uppercase tracking-[0.14em] text-white/60">{s.label}</span>
              </div>
            ))}
            <div className="flex items-baseline gap-2">
              <span className="font-display text-[18px] font-extrabold text-white sm:text-[22px]">{hero.regionalLabel}</span>
              <span className="text-[12px] font-semibold uppercase tracking-[0.14em] text-white/60">{hero.networkLabel}</span>
            </div>
          </motion.div>

          {/* ─── Carousel dots ─── */}
          <div          className="hero-dots mt-5 flex items-center gap-2">
            {heroSlides.map((_, i) => (
              <button
                key={i}
                onClick={() => setSlide(i)}
                className={`h-1.5 rounded-full transition-all duration-300 ${
                  i === slide ? "w-6 bg-[#5aabff]" : "w-1.5 bg-white/25 hover:bg-white/40"
                }`}
                aria-label={fmt(hero.slideAria, { n: i + 1 })}
              />
            ))}
          </div>
        </div>

        {/* ─── Scroll Indicator ─── */}
        <div className="hero-scroll pointer-events-none absolute bottom-4 end-6 hidden items-center gap-3 text-[12px] font-semibold uppercase tracking-[0.3em] text-white/35 md:flex">
          {hero.scroll}
          <span className="relative block h-9 w-px overflow-hidden bg-white/15">
            <span className="absolute inset-x-0 top-0 h-3.5 animate-[scrolldown_1.8s_ease-in-out_infinite] bg-white/50" aria-hidden />
          </span>
          <style>{`
            @keyframes scrolldown{0%{transform:translateY(-100%)}60%,100%{transform:translateY(260%)}}
            .no-raf-fallback [style*="opacity: 0"],
            .no-raf-fallback [style*="opacity:0"] {
              opacity: 1 !important;
              transform: none !important;
            }
          `}</style>
        </div>
      </section>

      {/* ─── Floating Mobile CTA ─── */}
      <div
        className={`fixed bottom-5 left-4 right-4 z-40 transition-all duration-500 md:hidden ${
          scrolledPast ? "translate-y-0 opacity-100" : "translate-y-6 opacity-0 pointer-events-none"
        }`}
      >
        <Link
          href={lhref("/contact#charter")}
          className="flex items-center justify-center gap-2 rounded-full bg-[#0078FF] px-5 py-3.5 text-[13px] font-semibold text-white shadow-[0_8px_30px_-4px_rgba(0,120,255,0.60)]"
        >
          {hero.floatingCta}
        </Link>
      </div>
    </>
  );
}
